"use client";

import { useEffect, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  BarChart3,
  Bell,
  Bot,
  ChevronDown,
  Home,
  LineChart,
  Search,
  Settings,
  ShieldCheck,
  Star,
  Target,
  TrendingDown,
  TrendingUp,
  Wallet,
  Zap,
} from "lucide-react";

type MarketSnapshot = {
  symbol: string;
  price: number;
  change: number;
  regime: "BULLISH" | "BEARISH" | "NEUTRAL";
};

const navigation = [
  { label: "Overview", icon: Home },
  { label: "Signals", icon: Zap },
  { label: "Markets", icon: BarChart3 },
  { label: "Scanner", icon: Search },
  { label: "Watchlist", icon: Star },
  { label: "AI Analyst", icon: Bot },
  { label: "Risk", icon: ShieldCheck },
  { label: "Performance", icon: Activity },
  { label: "Portfolio", icon: Wallet },
  { label: "Settings", icon: Settings },
];

const markets: MarketSnapshot[] = [
  {
    symbol: "BTCUSDT",
    price: 0,
    change: 0,
    regime: "NEUTRAL",
  },
  {
    symbol: "ETHUSDT",
    price: 0,
    change: 0,
    regime: "NEUTRAL",
  },
  {
    symbol: "SOLUSDT",
    price: 0,
    change: 0,
    regime: "NEUTRAL",
  },
];

export default function HomePage() {
  const [marketData, setMarketData] =
    useState<MarketSnapshot[]>(markets);

  const [performance, setPerformance] = useState({
    totalTrades: 0,
    winRate: 0,
    totalR: 0,
    averageR: 0,
  });

  useEffect(() => {
    async function loadPerformance() {
      try {
        const response = await fetch(
          "/api/trading/performance"
        );

        const data = await response.json();

        if (data.success) {
          setPerformance({
            totalTrades: data.summary.totalTrades,
            winRate: data.summary.winRate,
            totalR: data.summary.totalR,
            averageR: data.summary.averageR,
          });
        }
      } catch {
        // Keep dashboard available if analytics is unavailable.
      }
    }

    loadPerformance();
  }, []);

  return (
    <main className="min-h-screen bg-[#06070a] text-white">
      <div className="flex min-h-screen">

        {/* SIDEBAR */}

        <aside className="hidden w-[240px] shrink-0 border-r border-white/[0.06] bg-[#08090d] lg:flex lg:flex-col">

          <div className="flex h-[76px] items-center border-b border-white/[0.06] px-5">

            <div className="flex items-center gap-3">

              <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600">
                <span className="text-sm font-bold">
                  α
                </span>

                <div className="absolute -bottom-1 -right-1 h-2.5 w-2.5 rounded-full border-2 border-[#08090d] bg-emerald-400" />
              </div>

              <div>
                <div className="text-[15px] font-semibold tracking-tight">
                  hiddenalpha
                </div>

                <div className="mt-0.5 text-[9px] font-medium tracking-[0.24em] text-zinc-600">
                  TRADING INTELLIGENCE
                </div>
              </div>

            </div>

          </div>

          <div className="px-3 pt-5">

            <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-zinc-700">
              Workspace
            </p>

            <nav className="space-y-1">

              {navigation.map((item) => {
                const Icon = item.icon;
                const active = item.label === "Overview";

                return (
                  <div
                    key={item.label}
                    className={`group flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] transition ${
                      active
                        ? "bg-violet-500/10 text-white"
                        : "text-zinc-500 hover:bg-white/[0.03] hover:text-zinc-300"
                    }`}
                  >

                    <Icon
                      size={17}
                      strokeWidth={1.8}
                      className={
                        active
                          ? "text-violet-400"
                          : "text-zinc-600 group-hover:text-zinc-400"
                      }
                    />

                    <span>{item.label}</span>

                    {item.label === "Signals" && (
                      <span className="ml-auto rounded-md bg-violet-500/10 px-1.5 py-0.5 text-[9px] text-violet-400">
                        LIVE
                      </span>
                    )}

                  </div>
                );
              })}

            </nav>

          </div>

          <div className="mt-auto p-4">

            <div className="mb-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4">

              <div className="flex items-center justify-between">

                <span className="text-[11px] text-zinc-500">
                  Data engine
                </span>

                <span className="flex items-center gap-1.5 text-[10px] text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  Online
                </span>

              </div>

              <div className="mt-3 h-px bg-white/[0.05]" />

              <div className="mt-3 flex items-center justify-between text-[10px]">
                <span className="text-zinc-600">
                  Market source
                </span>

                <span className="text-zinc-400">
                  Bybit
                </span>
              </div>

            </div>

            <div className="flex items-center gap-3 rounded-xl px-2 py-2">

              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 text-[11px] font-semibold">
                T
              </div>

              <div className="min-w-0 flex-1">

                <p className="truncate text-[12px] font-medium">
                  Trader
                </p>

                <p className="truncate text-[10px] text-zinc-600">
                  Personal workspace
                </p>

              </div>

              <ChevronDown
                size={13}
                className="text-zinc-700"
              />

            </div>

          </div>

        </aside>

        {/* MAIN */}

        <section className="min-w-0 flex-1">

          {/* TOP BAR */}

          <header className="flex h-[76px] items-center border-b border-white/[0.06] px-5 lg:px-8">

            <div className="relative hidden w-full max-w-[460px] md:block">

              <Search
                size={16}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-700"
              />

              <input
                placeholder="Search markets, signals or tools..."
                className="h-10 w-full rounded-xl border border-white/[0.07] bg-white/[0.025] pl-10 pr-16 text-[12px] text-white outline-none placeholder:text-zinc-700 focus:border-violet-500/30"
              />

              <span className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md border border-white/[0.07] px-1.5 py-1 text-[9px] text-zinc-700">
                Ctrl K
              </span>

            </div>

            <div className="ml-auto flex items-center gap-5">

              <Bell
                size={18}
                className="text-zinc-600"
              />

              <div className="h-7 w-px bg-white/[0.06]" />

              <div className="flex items-center gap-2.5">

                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-500 text-[10px] font-semibold">
                  T
                </div>

                <div className="hidden sm:block">
                  <p className="text-[11px] font-medium">
                    Trader
                  </p>

                  <p className="text-[9px] text-zinc-700">
                    Personal
                  </p>
                </div>

              </div>

            </div>

          </header>

          {/* DASHBOARD */}

          <div className="mx-auto max-w-[1500px] p-5 lg:p-8">

            {/* HERO */}

            <div className="relative overflow-hidden rounded-3xl border border-white/[0.06] bg-[#0a0c10] p-6 lg:p-8">

              <div className="absolute -right-24 -top-32 h-72 w-72 rounded-full bg-violet-600/10 blur-3xl" />

              <div className="absolute -bottom-32 left-1/3 h-64 w-64 rounded-full bg-cyan-500/[0.06] blur-3xl" />

              <div className="relative">

                <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">

                  <div>

                    <div className="mb-3 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-violet-400">
                      <Activity size={13} />
                      Market intelligence
                    </div>

                    <h1 className="max-w-2xl text-[30px] font-semibold tracking-[-0.04em] lg:text-[36px]">
                      See the market.
                      <br />
                      Understand the signal.
                    </h1>

                    <p className="mt-3 max-w-xl text-[12px] leading-6 text-zinc-600">
                      Your trading intelligence workspace for
                      market context, signals, risk and execution.
                    </p>

                  </div>

                  <button className="flex h-10 items-center gap-2 self-start rounded-xl bg-violet-600 px-4 text-[11px] font-medium transition hover:bg-violet-500 lg:self-auto">
                    <Zap size={14} />
                    Scan Market
                  </button>

                </div>

              </div>

            </div>

            {/* MARKET TICKERS */}

            <div className="mt-3 grid gap-3 md:grid-cols-3">

              {marketData.map((market) => (

                <div
                  key={market.symbol}
                  className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5"
                >

                  <div className="flex items-center justify-between">

                    <div className="flex items-center gap-3">

                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/[0.035] text-[11px] font-semibold text-zinc-400">
                        {market.symbol.slice(0, 3)}
                      </div>

                      <div>

                        <p className="text-[12px] font-medium">
                          {market.symbol}
                        </p>

                        <p className="mt-0.5 text-[9px] text-zinc-700">
                          Perpetual
                        </p>

                      </div>

                    </div>

                    <span className="rounded-md bg-zinc-500/10 px-2 py-1 text-[9px] text-zinc-600">
                      1H
                    </span>

                  </div>

                  <div className="mt-5 flex items-end justify-between">

                    <div>

                      <p className="text-[21px] font-semibold tracking-tight">
                        {market.price > 0
                          ? market.price.toLocaleString()
                          : "—"}
                      </p>

                      <p className="mt-1 text-[9px] text-zinc-700">
                        Live market price
                      </p>

                    </div>

                    <div className="text-right">

                      <p className="text-[11px] text-zinc-600">
                        —
                      </p>

                      <p className="mt-1 text-[9px] text-zinc-700">
                        24h change
                      </p>

                    </div>

                  </div>

                </div>

              ))}

            </div>

            {/* CORE GRID */}

            <div className="mt-3 grid gap-3 xl:grid-cols-[1.45fr_1fr]">

              {/* MARKET CONTEXT */}

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center justify-between">

                  <div>

                    <h2 className="text-[13px] font-medium">
                      Market context
                    </h2>

                    <p className="mt-1 text-[10px] text-zinc-700">
                      Multi-factor market intelligence
                    </p>

                  </div>

                  <button className="flex items-center gap-1 text-[10px] text-zinc-600 hover:text-zinc-400">
                    View markets
                    <ArrowUpRight size={12} />
                  </button>

                </div>

                <div className="mt-5 grid gap-2 md:grid-cols-3">

                  <div className="rounded-xl border border-white/[0.05] bg-white/[0.015] p-4">

                    <div className="flex items-center gap-2">
                      <TrendingUp
                        size={14}
                        className="text-emerald-400"
                      />

                      <span className="text-[10px] text-zinc-600">
                        Trend
                      </span>
                    </div>

                    <p className="mt-4 text-[18px] font-medium">
                      Monitoring
                    </p>

                    <p className="mt-1 text-[9px] text-zinc-700">
                      EMA structure
                    </p>

                  </div>

                  <div className="rounded-xl border border-white/[0.05] bg-white/[0.015] p-4">

                    <div className="flex items-center gap-2">
                      <Activity
                        size={14}
                        className="text-cyan-400"
                      />

                      <span className="text-[10px] text-zinc-600">
                        Momentum
                      </span>
                    </div>

                    <p className="mt-4 text-[18px] font-medium">
                      Monitoring
                    </p>

                    <p className="mt-1 text-[9px] text-zinc-700">
                      RSI + momentum
                    </p>

                  </div>

                  <div className="rounded-xl border border-white/[0.05] bg-white/[0.015] p-4">

                    <div className="flex items-center gap-2">
                      <BarChart3
                        size={14}
                        className="text-amber-400"
                      />

                      <span className="text-[10px] text-zinc-600">
                        Volume
                      </span>
                    </div>

                    <p className="mt-4 text-[18px] font-medium">
                      Monitoring
                    </p>

                    <p className="mt-1 text-[9px] text-zinc-700">
                      Relative activity
                    </p>

                  </div>

                </div>

                <div className="mt-3 rounded-xl border border-violet-500/10 bg-violet-500/[0.025] p-4">

                  <div className="flex items-center gap-2">

                    <Bot
                      size={14}
                      className="text-violet-400"
                    />

                    <span className="text-[10px] font-medium text-violet-300">
                      Alpha Context Engine
                    </span>

                  </div>

                  <p className="mt-2 text-[11px] leading-5 text-zinc-600">
                    Price, volume, volatility, market structure
                    and momentum are being combined into a unified
                    market context.
                  </p>

                </div>

              </div>

              {/* SIGNAL CENTER */}

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center justify-between">

                  <div>

                    <h2 className="text-[13px] font-medium">
                      Signal center
                    </h2>

                    <p className="mt-1 text-[10px] text-zinc-700">
                      Current trading intelligence
                    </p>

                  </div>

                  <span className="flex items-center gap-1.5 text-[9px] text-zinc-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-zinc-600" />
                    Waiting
                  </span>

                </div>

                <div className="mt-6 rounded-2xl border border-white/[0.05] bg-[#080a0e] p-5">

                  <div className="flex items-center justify-between">

                    <span className="text-[10px] uppercase tracking-[0.14em] text-zinc-700">
                      Current setup
                    </span>

                    <span className="rounded-md bg-zinc-500/10 px-2 py-1 text-[9px] text-zinc-600">
                      MTF
                    </span>

                  </div>

                  <div className="mt-8 text-center">

                    <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-zinc-500/5">
                      <Target
                        size={22}
                        className="text-zinc-700"
                      />
                    </div>

                    <p className="mt-4 text-[13px] font-medium">
                      No confirmed setup
                    </p>

                    <p className="mx-auto mt-2 max-w-[240px] text-[10px] leading-5 text-zinc-700">
                      Hiddenalpha is waiting for enough market
                      confirmation before generating a trade idea.
                    </p>

                  </div>

                  <button className="mt-6 flex h-9 w-full items-center justify-center gap-2 rounded-xl border border-white/[0.07] text-[10px] text-zinc-500 transition hover:bg-white/[0.03] hover:text-zinc-300">
                    Open Signal Scanner
                    <ArrowUpRight size={12} />
                  </button>

                </div>

              </div>

            </div>

            {/* PERFORMANCE */}

            <div className="mt-3 grid gap-3 lg:grid-cols-4">

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center gap-2 text-zinc-600">
                  <Target size={14} />
                  <span className="text-[10px]">
                    Total trades
                  </span>
                </div>

                <p className="mt-4 text-[24px] font-semibold">
                  {performance.totalTrades}
                </p>

                <p className="mt-1 text-[9px] text-zinc-700">
                  Completed signals
                </p>

              </div>

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center gap-2 text-zinc-600">
                  <TrendingUp size={14} />
                  <span className="text-[10px]">
                    Win rate
                  </span>
                </div>

                <p className="mt-4 text-[24px] font-semibold">
                  {performance.winRate.toFixed(1)}%
                </p>

                <p className="mt-1 text-[9px] text-zinc-700">
                  Decided trades
                </p>

              </div>

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center gap-2 text-zinc-600">
                  <LineChart size={14} />
                  <span className="text-[10px]">
                    Total R
                  </span>
                </div>

                <p className="mt-4 text-[24px] font-semibold">
                  {performance.totalR >= 0 ? "+" : ""}
                  {performance.totalR.toFixed(2)}R
                </p>

                <p className="mt-1 text-[9px] text-zinc-700">
                  Realized performance
                </p>

              </div>

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center gap-2 text-zinc-600">
                  <ShieldCheck size={14} />
                  <span className="text-[10px]">
                    Avg R
                  </span>
                </div>

                <p className="mt-4 text-[24px] font-semibold">
                  {performance.averageR >= 0 ? "+" : ""}
                  {performance.averageR.toFixed(2)}R
                </p>

                <p className="mt-1 text-[9px] text-zinc-700">
                  Per completed trade
                </p>

              </div>

            </div>

            {/* BOTTOM */}

            <div className="mt-3 grid gap-3 lg:grid-cols-3">

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center justify-between">

                  <div>

                    <h2 className="text-[13px] font-medium">
                      Risk engine
                    </h2>

                    <p className="mt-1 text-[10px] text-zinc-700">
                      Before every trade
                    </p>

                  </div>

                  <ShieldCheck
                    size={16}
                    className="text-emerald-400"
                  />

                </div>

                <div className="mt-5 flex items-center justify-between rounded-xl border border-emerald-500/10 bg-emerald-500/[0.025] p-4">

                  <div>

                    <p className="text-[11px] font-medium">
                      Risk controls active
                    </p>

                    <p className="mt-1 text-[9px] text-zinc-700">
                      Position sizing + R/R validation
                    </p>

                  </div>

                  <span className="h-2 w-2 rounded-full bg-emerald-400" />

                </div>

              </div>

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center justify-between">

                  <div>

                    <h2 className="text-[13px] font-medium">
                      AI Analyst
                    </h2>

                    <p className="mt-1 text-[10px] text-zinc-700">
                      Decision support
                    </p>

                  </div>

                  <Bot
                    size={16}
                    className="text-violet-400"
                  />

                </div>

                <div className="mt-5">

                  <p className="text-[11px] leading-5 text-zinc-600">
                    AI will explain market context, signal
                    reasoning, invalidation levels and risk.
                  </p>

                  <button className="mt-4 flex items-center gap-2 text-[10px] text-violet-400">
                    Open AI Analyst
                    <ArrowUpRight size={12} />
                  </button>

                </div>

              </div>

              <div className="rounded-2xl border border-white/[0.06] bg-[#0a0c10] p-5">

                <div className="flex items-center justify-between">

                  <div>

                    <h2 className="text-[13px] font-medium">
                      Execution
                    </h2>

                    <p className="mt-1 text-[10px] text-zinc-700">
                      Trading workflow
                    </p>

                  </div>

                  <Wallet
                    size={16}
                    className="text-cyan-400"
                  />

                </div>

                <div className="mt-5 flex items-center justify-between">

                  <div>

                    <p className="text-[11px] font-medium">
                      Manual execution
                    </p>

                    <p className="mt-1 text-[9px] text-zinc-700">
                      Exchange connection coming next
                    </p>

                  </div>

                  <span className="rounded-md bg-zinc-500/10 px-2 py-1 text-[9px] text-zinc-600">
                    V1
                  </span>

                </div>

              </div>

            </div>

          </div>

        </section>

      </div>
    </main>
  );
}