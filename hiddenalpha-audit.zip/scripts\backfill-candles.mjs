const BASE_URL = "http://localhost:3000";

const SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "SOLUSDT",
];

const TIMEFRAMES = [
  "1m",
  "3m",
  "5m",
  "15m",
  "30m",
  "1h",
  "2h",
  "4h",
  "6h",
  "12h",
  "1d",
  "1w",
  "1M",
];

const LIMIT = 2000;

async function backfill() {
  console.log("========================================");
  console.log("HIDDENALPHA HISTORICAL BACKFILL");
  console.log("========================================");
  console.log("");

  let successCount = 0;
  let failedCount = 0;

  for (const symbol of SYMBOLS) {
    for (const timeframe of TIMEFRAMES) {
      console.log(
        `[BACKFILL] ${symbol} ${timeframe} ...`
      );

      try {
        const url =
          `${BASE_URL}/api/market/candles` +
          `?symbol=${symbol}` +
          `&timeframe=${timeframe}` +
          `&limit=${LIMIT}`;

        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok || !data.success) {
          throw new Error(
            data.error ||
              `HTTP ${response.status}`
          );
        }

        console.log(
          `  ✓ ${symbol} ${timeframe} → ${data.count} candles`
        );

        successCount++;
      } catch (error) {
        console.log(
          `  ✗ ${symbol} ${timeframe} → ${
            error instanceof Error
              ? error.message
              : String(error)
          }`
        );

        failedCount++;
      }
    }
  }

  console.log("");
  console.log("========================================");
  console.log("BACKFILL COMPLETE");
  console.log("========================================");
  console.log(`Success : ${successCount}`);
  console.log(`Failed  : ${failedCount}`);
  console.log("");
}

backfill();